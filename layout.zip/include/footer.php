</div> <!-- End of container -->
<footer class="bg-dark text-white text-center py-3 mt-auto">
    <p>&copy; 2025 LioraEdu. All rights reserved.</p>
</footer>
<script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>